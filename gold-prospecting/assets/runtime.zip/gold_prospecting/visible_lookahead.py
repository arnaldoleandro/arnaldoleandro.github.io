﻿"""Two visible placements, frozen afterstate DQN leaves, no future draws."""

import math
import time
from dataclasses import asdict

import numpy as np

from .bitboard import legal_actions
from .hybrid_finish import VisibleFinishPolicy
from .selfplay_dqn import candidates, greedy_index, reward


class VisibleLookaheadPolicy(VisibleFinishPolicy):
    """Preserve certified finishes; otherwise rerank a bounded root shortlist.

    A network afterstate value already includes that placement's reward. Thus
    a two-step root is scored as r(first) + Q(after second), with gamma=1.
    Exhausting the visible hand is a leaf, never an invented refill.
    """

    def __init__(self, network, config, max_seconds=.1, max_nodes=20000, *,
                 root_width=8, max_leaf_nodes=5000, max_plan_seconds=.1):
        super().__init__(network, config, max_seconds, max_nodes)
        for name, value in (("root_width", root_width), ("max_leaf_nodes", max_leaf_nodes)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if not math.isfinite(max_plan_seconds) or max_plan_seconds < 0:
            raise ValueError("max_plan_seconds must be finite and nonnegative")
        self.root_width = root_width
        self.max_leaf_nodes = max_leaf_nodes
        self.max_plan_seconds = float(max_plan_seconds)

    def choose(self, state):
        baseline = super().choose(state)
        if self.last_decision["source"] != "baseline":
            return baseline
        started = time.monotonic()
        self.stats["planning_calls"] += 1
        baseline_details = self.last_decision.copy()
        details = {"baseline_action": asdict(baseline), "frontier_complete": False,
                   "nodes": 0, "root_width": 0, "actual_future_exposed": False}

        def fallback(reason):
            details.update(fallback_reason=reason, seconds=time.monotonic() - started)
            self.stats["planning_fallbacks"] += 1
            self.stats["planning_seconds"] += details["seconds"]
            self.last_decision = {**baseline_details, "planning": details}
            return baseline

        def expired():
            return time.monotonic() - started >= self.max_plan_seconds

        if expired():
            return fallback("time_limit")
        actions, afters, _, inputs = candidates(state, self.config)
        try:
            values = np.asarray(self.network.predict(inputs), dtype=float)
        except FloatingPointError:
            return fallback("nonfinite_scores")
        if values.shape != (len(actions),) or not np.all(np.isfinite(values)):
            return fallback("nonfinite_scores")
        base = actions.index(baseline)
        details["baseline_network_value"] = float(values[base])
        # Match greedy_index: if any live root exists, physical dead ends are ineligible.
        eligible = [i for i, after in enumerate(afters) if not after.done]
        eligible = eligible or list(range(len(actions)))
        order = sorted(eligible, key=lambda i: (-values[i], i != base, i))
        roots = [base, *(i for i in order if i != base)][:self.root_width]
        details["root_width"] = len(roots)
        root_values = {}
        for index in roots:
            if expired():
                return fallback("time_limit")
            after = afters[index]
            if after.done and not after.won and after.moves >= self.config.max_moves:
                return fallback("move_cap_unknown")
            if after.done:
                root_values[index] = reward(True, after.won, after.moves)
                continue
            if not after.hand:
                root_values[index] = float(values[index])
                continue
            count = len(legal_actions(after))
            if details["nodes"] + count > self.max_leaf_nodes:
                return fallback("node_limit")
            leaf_actions, leaves, _, leaf_inputs = candidates(after, self.config)
            details["nodes"] += len(leaves)
            self.stats["planning_nodes"] += len(leaves)
            # Parent scanned every immediate action: any checked two-step win is minimal.
            winners = [j for j, leaf in enumerate(leaves) if leaf.won]
            if winners:
                path = (actions[index], leaf_actions[winners[0]])
                result = {"status": "win", "optimality_certified": True,
                          "minimum_moves": 2, "actions": path}
                queue = self._validated_queue(state, result)
                if queue:
                    self._queue = queue
                    witness_id = len(self.witnesses)
                    self.witnesses.append({"state": asdict(state),
                                           "actions": [asdict(a) for a in path],
                                           "minimum_moves": 2,
                                           "optimality_certified": True,
                                           "actual_future_exposed": False})
                    _, action = self._queue.pop(0)
                    details.update(seconds=time.monotonic() - started,
                                   fallback_reason=None, certificate_found=True)
                    self.stats["planning_seconds"] += details["seconds"]
                    return self._decide(action, "certified", witness_id=witness_id,
                                        minimum_moves=2, planning=details)
                return fallback("invalid_certificate")
            if any(leaf.done and leaf.moves >= self.config.max_moves for leaf in leaves):
                return fallback("move_cap_unknown")
            try:
                scores = np.asarray(self.network.predict(leaf_inputs), dtype=float)
            except FloatingPointError:
                return fallback("nonfinite_scores")
            if scores.shape != (len(leaves),) or not np.all(np.isfinite(scores)):
                return fallback("nonfinite_scores")
            for j, leaf in enumerate(leaves):
                if leaf.done:
                    scores[j] = reward(True, leaf.won, leaf.moves)
            choice = greedy_index(leaves, scores, self.config)
            root_values[index] = reward(False, False, after.moves) + float(scores[choice])
        if expired():
            return fallback("time_limit")
        best = max(roots, key=lambda i: (root_values[i], i == base))
        details.update(frontier_complete=True, fallback_reason=None,
                       seconds=time.monotonic() - started,
                       baseline_score=root_values[base], selected_score=root_values[best],
                       root_scores=[{"action": asdict(actions[i]), "score": root_values[i]}
                                    for i in roots])
        self.stats["planning_seconds"] += details["seconds"]
        self.stats["planning_complete"] += 1
        if best != base:
            self.stats["planning_changed"] += 1
        return self._decide(actions[best], "lookahead", planning=details)

    act = choose
