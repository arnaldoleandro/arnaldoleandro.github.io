"""Bit-mask planning backend; public rules engine remains the replay authority."""

from dataclasses import replace
from functools import lru_cache

from .engine import Action, State, Transition, neutralize_completed_colors


def planes(board):
    occupied, gems = 0, [0, 0, 0]
    cols = len(board[0])
    for r, row in enumerate(board):
        for c, value in enumerate(row):
            bit = 1 << (r * cols + c)
            if value:
                occupied |= bit
            if value in (1, 2, 3):
                gems[value - 1] |= bit
    return occupied, tuple(gems)


@lru_cache(maxsize=2048)
def placements(piece, rows, cols):
    height = max(r for r, _, _ in piece.cells) + 1
    width = max(c for _, c, _ in piece.cells) + 1
    result = []
    for r in range(rows - height + 1):
        for c in range(cols - width + 1):
            mask, gems = 0, [0, 0, 0]
            for dr, dc, value in piece.cells:
                bit = 1 << ((r + dr) * cols + c + dc)
                mask |= bit
                if value in (1, 2, 3):
                    gems[value - 1] |= bit
            result.append((r, c, mask, tuple(gems)))
    return tuple(result)


@lru_cache(maxsize=32)
def lines(rows, cols):
    return (tuple(((1 << cols) - 1) << (r * cols) for r in range(rows)),
            tuple(sum(1 << (r * cols + c) for r in range(rows)) for c in range(cols)))


def legal_actions(state):
    if state.done:
        return []
    occupied, _ = planes(state.board)
    rows, cols = len(state.board), len(state.board[0])
    return [Action(i, r, c) for i, piece in enumerate(state.hand)
            for r, c, mask, _ in placements(piece, rows, cols) if not occupied & mask]


def place(state, action, config):
    state = neutralize_completed_colors(state, config)
    if state.done or not 0 <= action.piece_index < len(state.hand):
        raise ValueError("Illegal action")
    occupied, gems = planes(state.board)
    options = placements(state.hand[action.piece_index], config.rows, config.cols)
    option = next((item for item in options if item[:2] == (action.row, action.col)), None)
    if option is None or occupied & option[2]:
        raise ValueError("Illegal action")
    occupied |= option[2]
    gems = tuple(a | b for a, b in zip(gems, option[3]))
    row_masks, col_masks = lines(config.rows, config.cols)
    full_rows = tuple(i for i, mask in enumerate(row_masks) if occupied & mask == mask)
    full_cols = tuple(i for i, mask in enumerate(col_masks) if occupied & mask == mask)
    clear = 0
    for i in full_rows:
        clear |= row_masks[i]
    for i in full_cols:
        clear |= col_masks[i]
    if config.intersection_counts_once:
        gained = tuple((mask & clear).bit_count() for mask in gems)
    else:
        gained = tuple(sum((mask & row_masks[i]).bit_count() for i in full_rows)
                       + sum((mask & col_masks[i]).bit_count() for i in full_cols)
                       for mask in gems)
    occupied &= ~clear
    gems = tuple(mask & ~clear for mask in gems)
    board = tuple(tuple(next((i + 1 for i, mask in enumerate(gems) if mask & (1 << (r * config.cols + c))),
                             4 if occupied & (1 << (r * config.cols + c)) else 0)
                        for c in range(config.cols)) for r in range(config.rows))
    collected = tuple(a + b for a, b in zip(state.collected, gained))
    won = all(a >= b for a, b in zip(collected, config.targets))
    hand = state.hand[:action.piece_index] + state.hand[action.piece_index + 1:]
    after = neutralize_completed_colors(State(board, hand, collected, state.moves + 1,
        won or state.moves + 1 >= config.max_moves, won), config)
    if not after.done and hand:
        # Stop at the first fit, including pieces other than a blocked slot.
        fits = any(not occupied & mask for piece in after.hand
                   for _, _, mask, _ in placements(piece, config.rows, config.cols))
        if not fits:
            after = replace(after, done=True)
    return Transition(after, full_rows, full_cols, gained)
