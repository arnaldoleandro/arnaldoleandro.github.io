"""Pure game rules. Defaults are illustrative, NOT verified Last War internals."""
from __future__ import annotations

import random
from collections.abc import Iterator, Sequence
from dataclasses import dataclass, field, replace

EMPTY = 0
COLORS = (1, 2, 3)  # green, yellow, blue (labels configurable externally)
PLAIN = 4  # Occupied block without a gem; never counted as a collected gem.
OCCUPIED_VALUES = (*COLORS, PLAIN)

# Offsets relative to the top-left of each piece; no rotation by default.
DEFAULT_SHAPES: tuple[tuple[tuple[int, int], ...], ...] = (
    ((0, 0),), ((0, 0), (0, 1)), ((0, 0), (1, 0)),
    ((0, 0), (0, 1), (0, 2)), ((0, 0), (1, 0), (2, 0)),
    ((0, 0), (0, 1), (1, 0)), ((0, 0), (0, 1), (1, 1)),
    ((0, 0), (1, 0), (1, 1)), ((0, 1), (1, 0), (1, 1)),
    ((0, 0), (0, 1), (1, 0), (1, 1)),
    ((0, 0), (0, 1), (0, 2), (0, 3)),
    ((0, 0), (1, 0), (2, 0), (3, 0)),
)

@dataclass(frozen=True)
class Config:
    rows: int = 8
    cols: int = 8
    targets: tuple[int, int, int] = (12, 12, 12)
    initial_fill: float = 0.16
    hand_size: int = 3
    max_moves: int = 200
    shapes: tuple[tuple[tuple[int, int], ...], ...] = DEFAULT_SHAPES
    # Player-confirmed rule: a shared cell contributes its gem only once.
    # False is retained only for counterfactual experiments / legacy compatibility.
    intersection_counts_once: bool = True
    cell_values: tuple[int, ...] = COLORS
    color_names: tuple[str, str, str] = ("green", "yellow", "blue")
    neutralize_completed_colors: bool = False

    def __post_init__(self):
        if self.rows < 2 or self.cols < 2 or self.hand_size < 1 or self.max_moves < 1:
            raise ValueError("Invalid board / hand / move limits")
        if not 0 <= self.initial_fill <= 1 or len(self.targets) != len(COLORS):
            raise ValueError("Invalid fill or targets")
        if any(t < 0 for t in self.targets):
            raise ValueError("Targets must be nonnegative")
        if not self.shapes or any(not shape or len(set(shape)) != len(shape) for shape in self.shapes):
            raise ValueError("Shapes must contain distinct cells")
        if any(r < 0 or c < 0 for shape in self.shapes for r, c in shape):
            raise ValueError("Shape offsets must be nonnegative")
        if not self.cell_values or any(value not in OCCUPIED_VALUES for value in self.cell_values):
            raise ValueError("Invalid generated cell values")
        if len(self.color_names) != len(COLORS) or len(set(self.color_names)) != len(COLORS):
            raise ValueError("Provide three distinct color names")

@dataclass(frozen=True)
class Piece:
    cells: tuple[tuple[int, int, int], ...]  # (row-offset, col-offset, gem color or PLAIN)

    def __post_init__(self):
        if not self.cells or len({(r, c) for r, c, _ in self.cells}) != len(self.cells):
            raise ValueError("Piece has duplicate or zero cells")
        if any(r < 0 or c < 0 or color not in OCCUPIED_VALUES for r, c, color in self.cells):
            raise ValueError("Invalid piece cell")

@dataclass(frozen=True)
class State:
    board: tuple[tuple[int, ...], ...]
    hand: tuple[Piece, ...]
    collected: tuple[int, int, int] = (0, 0, 0)
    moves: int = 0
    done: bool = False
    won: bool = False

@dataclass(frozen=True)
class Action:
    piece_index: int
    row: int
    col: int

@dataclass(frozen=True)
class Transition:
    state: State
    cleared_rows: tuple[int, ...]
    cleared_cols: tuple[int, ...]
    gained: tuple[int, int, int]


def neutralize_completed_colors(state: State, config: Config) -> State:
    """Remove completed gem icons while preserving occupancy and piece geometry.

    Observed for all three colors in match 001, on the board and remaining hand.
    Later captured hands omit completed green/pink; the sampling mechanism and
    post-yellow draws (the match is over) remain unobserved.
    """
    if not config.neutralize_completed_colors:
        return state
    completed = {color for color, got, target in zip(COLORS, state.collected, config.targets)
                 if got >= target}
    if not completed:
        return state
    return replace(
        state,
        board=tuple(tuple(PLAIN if value in completed else value for value in row)
                    for row in state.board),
        hand=tuple(Piece(tuple((r, c, PLAIN if value in completed else value)
                               for r, c, value in piece.cells)) for piece in state.hand),
    )


def make_piece(shape: Sequence[tuple[int, int]], rng: random.Random,
               cell_values: Sequence[int] = COLORS) -> Piece:
    return Piece(tuple((r, c, rng.choice(cell_values)) for r, c in shape))


def draw_hand(config: Config, rng: random.Random) -> tuple[Piece, ...]:
    return tuple(make_piece(rng.choice(config.shapes), rng, config.cell_values)
                 for _ in range(config.hand_size))


def new_game(config: Config, rng: random.Random) -> State:
    board = tuple(tuple(rng.choice(config.cell_values) if rng.random() < config.initial_fill else EMPTY
                        for _ in range(config.cols)) for _ in range(config.rows))
    state = State(board, draw_hand(config, rng))
    won = all(t == 0 for t in config.targets)
    return neutralize_completed_colors(
        State(board, state.hand, done=won or not has_legal_action(state), won=won), config)


def can_place(state: State, action: Action) -> bool:
    if state.done or not 0 <= action.piece_index < len(state.hand):
        return False
    piece = state.hand[action.piece_index]
    return all(0 <= action.row + r < len(state.board)
               and 0 <= action.col + c < len(state.board[0])
               and state.board[action.row + r][action.col + c] == EMPTY
               for r, c, _ in piece.cells)


def iter_legal_actions(state: State) -> Iterator[Action]:
    if state.done:
        return
    for idx, piece in enumerate(state.hand):
        height = max(r for r, _, _ in piece.cells) + 1
        width = max(c for _, c, _ in piece.cells) + 1
        for row in range(len(state.board) - height + 1):
            for col in range(len(state.board[0]) - width + 1):
                action = Action(idx, row, col)
                if can_place(state, action):
                    yield action


def legal_actions(state: State) -> list[Action]:
    return list(iter_legal_actions(state))


def has_legal_action(state: State) -> bool:
    """Stop at the first fit; planning need not enumerate the entire next hand."""
    return next(iter_legal_actions(state), None) is not None


def place(state: State, action: Action, config: Config) -> Transition:
    """Apply an action WITHOUT drawing a new hand (planning-friendly)."""
    state = neutralize_completed_colors(state, config)
    if not can_place(state, action):
        raise ValueError(f"Illegal action: {action}")
    grid = [list(row) for row in state.board]
    for r, c, color in state.hand[action.piece_index].cells:
        grid[action.row + r][action.col + c] = color
    full_rows = tuple(r for r in range(config.rows) if all(grid[r][c] for c in range(config.cols)))
    full_cols = tuple(c for c in range(config.cols) if all(grid[r][c] for r in range(config.rows)))
    positions = {(r, c) for r in full_rows for c in range(config.cols)} | {
        (r, c) for c in full_cols for r in range(config.rows)}
    counts = [0] * len(COLORS)
    if config.intersection_counts_once:
        for r, c in positions:
            if grid[r][c] in COLORS:
                counts[grid[r][c] - 1] += 1
    else:
        for r in full_rows:
            for c in range(config.cols):
                if grid[r][c] in COLORS:
                    counts[grid[r][c] - 1] += 1
        for c in full_cols:
            for r in range(config.rows):
                if grid[r][c] in COLORS:
                    counts[grid[r][c] - 1] += 1
    for r, c in positions:
        grid[r][c] = EMPTY
    collected = tuple(old + gain for old, gain in zip(state.collected, counts))
    won = all(got >= needed for got, needed in zip(collected, config.targets))
    hand = state.hand[:action.piece_index] + state.hand[action.piece_index + 1:]
    moves = state.moves + 1
    next_state = State(tuple(map(tuple, grid)), hand, collected, moves,
                       done=won or moves >= config.max_moves, won=won)
    next_state = neutralize_completed_colors(next_state, config)
    if not next_state.done and hand and not has_legal_action(next_state):
        next_state = replace(next_state, done=True)
    return Transition(next_state, full_rows, full_cols, tuple(counts))


@dataclass
class Game:
    config: Config = field(default_factory=Config)
    seed: int = 0
    rng: random.Random = field(init=False, repr=False)
    state: State = field(init=False)

    def __post_init__(self):
        self.reset(self.seed)

    def reset(self, seed: int | None = None) -> State:
        if seed is not None:
            self.seed = seed
        self.rng = random.Random(self.seed)
        self.state = new_game(self.config, self.rng)
        return self.state

    def step(self, action: Action) -> Transition:
        transition = place(self.state, action, self.config)
        state = transition.state
        if not state.done and not state.hand:
            replenished = State(state.board, draw_hand(self.config, self.rng),
                                state.collected, state.moves)
            replenished = neutralize_completed_colors(replenished, self.config)
            state = State(replenished.board, replenished.hand, replenished.collected,
                          replenished.moves, done=not has_legal_action(replenished))
        self.state = state
        return Transition(state, transition.cleared_rows, transition.cleared_cols,
                          transition.gained)


def render(state: State, config: Config | None = None) -> str:
    names = (config or Config()).color_names
    symbols = "." + "".join(name[0].upper() for name in names) + "#"
    board = "\n".join(" ".join(symbols[x] for x in row) for row in state.board)
    hand = " | ".join(str(i) + ":" + str([(r, c, symbols[k]) for r, c, k in p.cells])
                      for i, p in enumerate(state.hand))
    return f"{board}\nhand: {hand}\ncollected: {state.collected} moves: {state.moves} won: {state.won}"
