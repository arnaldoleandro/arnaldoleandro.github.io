"""Small CPU Double-DQN over deterministic action afterstates; NumPy only."""

import json
import os
from pathlib import Path

import numpy as np

from .bitboard import legal_actions, place
from .engine import Piece, State

PACKED = 145
FEATURES = 701
MODEL_VERSION = "afterstate-double-dqn-v1"


def pack(state):
    out = np.zeros(PACKED, dtype=np.uint16)
    out[:64] = np.asarray(state.board).ravel()
    pieces = sorted(tuple(sorted(p.cells)) for p in state.hand)
    for slot, cells in enumerate(pieces):
        for r, c, color in cells:
            if not 0 <= r < 5 or not 0 <= c < 5:
                raise ValueError("Piece exceeds the configured five-cell encoding")
            out[64 + slot * 25 + r * 5 + c] = color
    out[139:142] = np.minimum(state.collected, (5, 10, 5))
    out[142:] = state.moves, int(state.done), int(state.won)
    return out


def unpack(values):
    hand = []
    for slot in range(3):
        cells = tuple((i // 5, i % 5, int(c))
                      for i, c in enumerate(values[64 + slot * 25:89 + slot * 25]) if c)
        if cells:
            hand.append(Piece(cells))
    return State(tuple(tuple(map(int, row)) for row in values[:64].reshape(8, 8)),
                 tuple(hand), tuple(map(int, values[139:142])), int(values[142]),
                 bool(values[143]), bool(values[144]))


def features(packed):
    values = np.asarray(packed, dtype=np.uint16).reshape(-1, PACKED)
    cells = np.eye(5, dtype=np.float32)[values[:, :139]].reshape(len(values), -1)
    other = values[:, 139:].astype(np.float32)
    other[:, :3] /= np.asarray((5, 10, 5), dtype=np.float32)
    other[:, 3] /= 200.0
    return np.concatenate((cells, other), axis=1)


def reward(terminal, won, moves):
    # Every placement costs something. No gem/line bonuses or speed reward.
    bonus = (1.0 + .10 * (moves <= 11) + .02 * (moves <= 9)
             + .01 * (moves == 10)) if won else -1.0
    return -.001 + (bonus if terminal else 0.0)


class Network:
    def __init__(self, seed=0, hidden=64):
        rng = np.random.default_rng(seed)
        self.parameters = [rng.normal(0, np.sqrt(2 / FEATURES), (FEATURES, hidden)).astype(np.float32),
                           np.zeros(hidden, dtype=np.float32),
                           rng.normal(0, .01, (hidden, 1)).astype(np.float32),
                           np.zeros(1, dtype=np.float32)]
        self.m = [np.zeros_like(p) for p in self.parameters]
        self.v = [np.zeros_like(p) for p in self.parameters]
        self.updates = 0

    def predict(self, x):
        w, b, v, c = self.parameters
        z = x @ w + b
        return (np.where(z > 0, z, .01 * z) @ v + c).ravel()

    def train(self, x, targets, learning_rate=.0003):
        w, b, v, c = self.parameters
        z = x @ w + b
        hidden = np.where(z > 0, z, .01 * z)
        error = (hidden @ v + c).ravel() - targets
        delta = np.clip(error, -1, 1).reshape(-1, 1) / len(x)
        back = (delta @ v.T) * np.where(z > 0, 1, .01)
        grads = [x.T @ back, back.sum(axis=0), hidden.T @ delta, delta.sum(axis=0)]
        norm = np.sqrt(sum(float(np.sum(g * g)) for g in grads))
        self.updates += 1
        for i, grad in enumerate(grads):
            grad = grad * min(1, 10 / max(norm, 1e-12))
            self.m[i] = .9 * self.m[i] + .1 * grad
            self.v[i] = .999 * self.v[i] + .001 * grad * grad
            corrected_m = self.m[i] / (1 - .9 ** self.updates)
            corrected_v = self.v[i] / (1 - .999 ** self.updates)
            self.parameters[i] -= learning_rate * corrected_m / (np.sqrt(corrected_v) + 1e-8)
        return float(np.mean(np.where(np.abs(error) <= 1, .5 * error ** 2, np.abs(error) - .5)))

    def copy(self):
        result = Network(hidden=self.parameters[0].shape[1])
        result.parameters = [p.copy() for p in self.parameters]
        return result

    def arrays(self, prefix=""):
        return {**{f"{prefix}p{i}": p for i, p in enumerate(self.parameters)},
                **{f"{prefix}m{i}": p for i, p in enumerate(self.m)},
                **{f"{prefix}v{i}": p for i, p in enumerate(self.v)},
                f"{prefix}updates": np.asarray(self.updates)}

    @classmethod
    def restore(cls, arrays, prefix=""):
        result = cls(hidden=arrays[f"{prefix}p0"].shape[1])
        result.parameters = [arrays[f"{prefix}p{i}"].copy() for i in range(4)]
        result.m = [arrays[f"{prefix}m{i}"].copy() for i in range(4)]
        result.v = [arrays[f"{prefix}v{i}"].copy() for i in range(4)]
        result.updates = int(arrays[f"{prefix}updates"])
        return result


def candidates(state, config):
    actions = legal_actions(state)
    if not actions:
        raise ValueError("No legal actions")
    states = [place(state, a, config).state for a in actions]
    packed = np.stack([pack(s) for s in states])
    return actions, states, packed, features(packed)


def greedy_index(states, scores, config):
    winners = [i for i, s in enumerate(states) if s.won]
    if winners:
        return winners[0]
    live = [i for i, s in enumerate(states) if not s.done]
    choices = live or list(range(len(states)))
    return max(choices, key=lambda i: float(scores[i]))


def learn(network, target, replay, config, rng, batch_size=16):
    selected = rng.choice(len(replay), size=batch_size, replace=False)
    batch = [replay[int(i)] for i in selected]
    x = features(np.stack([item[0] for item in batch]))
    targets = np.asarray([item[1] for item in batch], dtype=np.float32)
    for i, (_current, _reward, next_packed, terminal) in enumerate(batch):
        if terminal:
            continue
        _actions, afters, _packed, inputs = candidates(unpack(next_packed), config)
        choice = greedy_index(afters, network.predict(inputs), config)
        after = afters[choice]
        if after.won or (after.done and after.moves < config.max_moves):
            value = reward(True, after.won, after.moves)
        else:
            value = float(target.predict(inputs[choice:choice + 1])[0])
        targets[i] += np.clip(value, -2, 2)  # gamma=1: undiscounted placement objective.
    return network.train(x, targets)


def save_npz(path, arrays, metadata):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as stream:
        np.savez_compressed(stream, **arrays, metadata=np.asarray(json.dumps(metadata)))
    os.replace(temporary, path)


def load_npz(path):
    with np.load(path, allow_pickle=False) as values:
        arrays = {name: values[name].copy() for name in values.files if name != "metadata"}
        metadata = json.loads(str(values["metadata"]))
    if metadata.get("model_version") != MODEL_VERSION:
        raise ValueError("Unsupported self-play checkpoint")
    return arrays, metadata
