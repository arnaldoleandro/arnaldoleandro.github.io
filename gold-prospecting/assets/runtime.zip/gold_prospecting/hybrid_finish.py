"""Greedy DQN with certified, current-hand-only shortest winning suffixes."""

import math
from collections import Counter
from dataclasses import asdict

from .bitboard import legal_actions
from .bitboard import place as fast_place
from .engine import place
from .selfplay_dqn import candidates, greedy_index
from .visible_finish import shortest_visible_finish


class VisibleFinishPolicy:
    """Keep the baseline until a fully replayed shortest visible win exists.

    A win in d <= len(hand) placements cannot require an unseen refill. Complete
    breadth-first layers certify that d is minimal from this state. Prefixes
    therefore match the baseline until intervention; thereafter the certified
    suffix cannot lose or take more placements than a baseline winning suffix.
    A resource limit provides no certificate and leaves the baseline unchanged.
    """

    def __init__(self, network, config, max_seconds=.1, max_nodes=20000):
        if not math.isfinite(max_seconds) or max_seconds < 0:
            raise ValueError("max_seconds must be finite and nonnegative")
        if isinstance(max_nodes, bool) or not isinstance(max_nodes, int) or max_nodes < 1:
            raise ValueError("max_nodes must be a positive integer")
        self.network, self.config = network, config
        self.max_seconds, self.max_nodes = float(max_seconds), max_nodes
        self.stats = Counter()
        self.search_status = Counter()
        self.witnesses = []
        self.certificates = self.witnesses
        self.last_decision = {}
        self._queue = []

    def info(self):
        return {"stats": dict(self.stats), "search_status": dict(self.search_status),
                "queued_actions": len(self._queue), "witnesses": self.witnesses,
                "last_decision": self.last_decision}

    def _decide(self, action, source, **details):
        self.last_decision = {"source": source, "action": asdict(action), **details}
        self.stats[source] += 1
        return action

    def _enough_inventory(self, state):
        counts = list(state.collected)
        for row in state.board:
            for color in row:
                if 1 <= color <= 3:
                    counts[color - 1] += 1
        for piece in state.hand:
            for _r, _c, color in piece.cells:
                if 1 <= color <= 3:
                    counts[color - 1] += 1
        return all(got >= goal for got, goal in zip(counts, self.config.targets))

    def _validated_queue(self, state, result):
        path = result.get("actions")
        if (result.get("status") != "win" or not result.get("optimality_certified")
                or not path or len(path) != result.get("minimum_moves")
                or len(path) > len(state.hand)):
            return None
        replay, queue = state, []
        try:
            for action in path:
                queue.append((replay, action))
                replay = place(replay, action, self.config).state
        except (ValueError, IndexError):
            return None
        return queue if replay.won else None

    def choose(self, state):
        self.stats["calls"] += 1
        if state.done:
            raise ValueError("Cannot choose an action in a terminal state")
        if self._queue:
            expected, action = self._queue[0]
            if state == expected:
                self._queue.pop(0)
                return self._decide(action, "queue")
            self.stats["queue_invalidations"] += 1
            self._queue.clear()
        actions = legal_actions(state)
        if not actions:
            raise ValueError("No legal actions")
        # greedy_index always takes the first immediate winner, regardless of Q.
        for action in actions:
            if fast_place(state, action, self.config).state.won:
                return self._decide(action, "immediate")
        search = None
        if self._enough_inventory(state):
            self.stats["searches"] += 1
            search = shortest_visible_finish(state, self.config,
                                            max_nodes=self.max_nodes,
                                            max_seconds=self.max_seconds)
            self.stats["search_seconds"] += search["seconds"]
            self.stats["search_nodes"] += search["nodes"]
            self.search_status[search["status"]] += 1
            queue = self._validated_queue(state, search)
            if queue:
                self._queue = queue
                witness_id = len(self.witnesses)
                self.witnesses.append({"state": asdict(state),
                                       "actions": [asdict(a) for a in search["actions"]],
                                       "minimum_moves": search["minimum_moves"],
                                       "optimality_certified": True,
                                       "actual_future_exposed": False})
                _, action = self._queue.pop(0)
                return self._decide(action, "certified", witness_id=witness_id,
                                    minimum_moves=search["minimum_moves"])
            if search["status"] == "win":
                self.stats["rejected_certificates"] += 1
        else:
            self.stats["inventory_skips"] += 1
        actions, afters, _packed, inputs = candidates(state, self.config)
        index = greedy_index(afters, self.network.predict(inputs), self.config)
        return self._decide(actions[index], "baseline",
                            search_status=search["status"] if search else "inventory_skip")

    act = choose
