"""Bounded exact shortest-win search using only the currently visible pieces."""

import time

from .bitboard import legal_actions, place
from .engine import place as checked_place


def shortest_visible_finish(state, config, max_nodes=40000, max_seconds=.75):
    if len(state.hand) > 3 or max_nodes < 1 or max_seconds < 0:
        raise ValueError("Expected at most three pieces and positive search limits")
    started = time.monotonic()
    deadline = started + max_seconds
    expanded = 0

    def result(status, path=None):
        return {"status": status, "minimum_moves": len(path) if path is not None else None,
                "actions": path, "nodes": expanded, "seconds": time.monotonic()-started,
                "optimality_certified": path is not None,
                "actual_future_exposed": False}

    if state.won:
        return result("win", ())
    frontier = [(state, ())]
    # Breadth-first layers are complete before exploring a larger move count.
    # A first win at depth k therefore certifies the minimum within the hand.
    # No refill is permitted, so unknown future pieces cannot enter the search.
    for _depth in range(len(state.hand)):
        following, seen = [], set()
        for current, path in frontier:
            for action in legal_actions(current):
                if expanded >= max_nodes:
                    return result("node_limit")
                if expanded % 64 == 0 and time.monotonic() >= deadline:
                    return result("time_limit")
                expanded += 1
                after = place(current, action, config).state
                steps = (*path, action)
                if after.won:
                    replay = state
                    for step in steps:
                        replay = checked_place(replay, step, config).state
                    if replay != after or not replay.won:
                        raise ValueError("Visible solution failed original-engine replay")
                    return result("win", steps)
                if after.done or not after.hand:
                    continue
                key = (after.board, after.hand, after.collected)
                if key not in seen:
                    seen.add(key)
                    following.append((after, steps))
        frontier = following
        if not frontier:
            break
    return result("no_visible_win_exhaustive")
