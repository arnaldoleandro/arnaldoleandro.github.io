"""Observed geometry and match goals; generation probabilities remain hypothetical."""

from .engine import COLORS, PLAIN, Config

# Orientations visible in partida-001 and through move 15 of partida-002.
# Still not an exhaustive catalog or a calibrated shape distribution.
OBSERVED_SHAPES = (
    ((0, 1), (1, 0), (1, 1), (2, 1)),
    ((0, 0), (0, 1), (0, 2), (1, 0)),
    ((0, 1), (1, 0), (1, 1), (2, 0)),
    ((0, 2), (1, 1), (2, 0)),
    ((0, 0), (0, 1), (0, 2)),
    ((0, 0),),
    ((0, 1), (1, 0)),
    ((0, 0), (0, 1), (1, 1), (1, 2)),
    ((0, 0), (0, 1), (0, 2), (1, 2)),
    ((0, 0), (0, 1), (1, 1), (2, 1)),
    ((0, 0), (1, 1), (2, 2)),
    ((0, 0), (1, 0), (2, 0), (3, 0)),
    ((0, 0), (0, 1), (1, 0), (1, 1)),
    ((0, 0), (1, 0), (2, 0)),
    ((0, 0), (0, 1), (1, 0)),
    ((0, 1), (0, 2), (1, 0), (1, 1)),
    ((0, 0), (0, 1)),
    ((0, 0), (1, 0), (1, 1), (2, 0)),
    ((0, 0), (1, 0), (1, 1), (2, 1)),
    ((0, 0), (1, 1)),
    ((0, 0), (1, 0), (2, 0), (2, 1)),
    ((0, 2), (1, 0), (1, 1), (1, 2)),
    ((0, 0), (0, 1), (1, 0), (2, 0)),
    ((0, 0), (1, 0), (1, 1), (1, 2)),
    ((0, 0), (1, 0)),
)


def observed_config(**overrides) -> Config:
    """Captured dimensions/goals and seen shapes, with an uncalibrated generator.

    Uniform sampling of shapes/cell values and random initial fill are experimental
    placeholders, not claims about the real game's distributions or initial layout.
    The default max_moves is a simulation safety cap, not an observed game rule.
    """
    settings = {
        "targets": (5, 10, 5),
        "color_names": ("green", "yellow", "pink"),
        "cell_values": (*COLORS, PLAIN),
        "shapes": OBSERVED_SHAPES,
        "neutralize_completed_colors": True,
    }
    settings.update(overrides)
    return Config(**settings)
