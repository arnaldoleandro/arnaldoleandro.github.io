"""Browser adapter. Imports the unchanged policy and reference replay engine."""
import json
from dataclasses import asdict

import numpy as np

from gold_prospecting.engine import Config, Piece, State, neutralize_completed_colors, place
from gold_prospecting.selfplay_dqn import Network
from gold_prospecting.visible_lookahead import VisibleLookaheadPolicy

_policy = None


def initialize(manifest_path, model_path):
    global _policy
    manifest = json.loads(open(manifest_path, encoding="utf-8").read())
    config = manifest["config"]
    for field in ("targets", "cell_values", "color_names"):
        config[field] = tuple(config[field])
    config["shapes"] = tuple(tuple(tuple(cell) for cell in shape) for shape in config["shapes"])
    network = Network.__new__(Network)
    with np.load(model_path, allow_pickle=False) as weights:
        if set(weights.files) != {"p0", "p1", "p2", "p3"}:
            raise ValueError("Unexpected inference weight fields")
        network.parameters = [weights[f"p{i}"].copy() for i in range(4)]
    _policy = VisibleLookaheadPolicy(network, Config(**config), **manifest["planning"])


def _integer(value, low, high, label):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{label}: expected an integer from {low} to {high}")
    return value


def read_state(raw):
    board = raw.get("board")
    if not isinstance(board, list) or len(board) != 8 or any(not isinstance(row, list) or len(row) != 8 for row in board):
        raise ValueError("Board must have eight rows of eight cells")
    board = tuple(tuple(_integer(v, 0, 4, "Board cell") for v in row) for row in board)
    hand = raw.get("hand")
    if not isinstance(hand, list) or not 1 <= len(hand) <= 3:
        raise ValueError("Provide one to three visible pieces")
    pieces = []
    for piece in hand:
        cells = piece.get("cells") if isinstance(piece, dict) else piece
        if not isinstance(cells, list) or not 1 <= len(cells) <= 9:
            raise ValueError("Piece needs one to nine cells")
        normalized = []
        for cell in cells:
            if not isinstance(cell, list) or len(cell) != 3:
                raise ValueError("Piece cells must be [row, col, color]")
            r, c, color = cell
            normalized.append((_integer(r, 0, 4, "Piece row"), _integer(c, 0, 4, "Piece column"),
                               _integer(color, 1, 4, "Piece color")))
        pieces.append(Piece(tuple(normalized)))
    collected = raw.get("collected", [0, 0, 0])
    if not isinstance(collected, list) or len(collected) != 3:
        raise ValueError("Collected must have three counters")
    collected = tuple(_integer(v, 0, 1000, "Collected") for v in collected)
    moves = _integer(raw.get("moves", 0), 0, 199, "Moves")
    if raw.get("done", False) or raw.get("won", False):
        raise ValueError("The game is already finished")
    if all(got >= target for got, target in zip(collected, _policy.config.targets)):
        raise ValueError("All targets have already been reached")
    return neutralize_completed_colors(State(board, tuple(pieces), collected, moves), _policy.config)


def solve(raw_json):
    raw = json.loads(raw_json)
    state = read_state(raw)
    action = _policy.choose(state)
    transition = place(state, action, _policy.config)
    cells = [[action.row + r, action.col + c, color]
             for r, c, color in state.hand[action.piece_index].cells]
    decision = dict(_policy.last_decision)
    path = []
    witness_id = decision.get("witness_id")
    if witness_id is not None:
        path = _policy.witnesses[witness_id]["actions"]
    elif decision["source"] == "queue":
        path = [asdict(action)] + [asdict(a) for _, a in _policy._queue]
    elif transition.state.won:
        path = [asdict(action)]
    # The browser has no reason to retain a history of certificate states.
    _policy.witnesses.clear()
    return json.dumps({"action": asdict(action), "decision": decision,
                       "placement_cells": cells, "expected_after": asdict(transition.state),
                       "gained": transition.gained, "cleared_rows": transition.cleared_rows,
                       "cleared_cols": transition.cleared_cols, "certified_path": path})
